import urwid

version = 'batchren 0.6.1'


class ArrangeBrowser:
    def __init__(self, files):
        self.palette = [
            ('titlebar', 'black', 'light gray'),
            ('titlebar-divide', 'black', 'black')
            ('body', 'black', 'light gray'),
            ('flagged', 'black', 'dark green',
                ('bold', 'underline')),
            ('focus', 'light gray', 'dark blue', 'standout'),
            ('flagged focus', 'yellow', 'dark cyan',
                ('bold', 'standout', 'underline')),
            ('head', 'yellow', 'black', 'standout'),
            ('foot', 'light gray', 'black'),
            ('key', 'light cyan', 'black', 'underline'),
            ('title', 'white', 'black', 'bold'),
            ('dirmark', 'black', 'dark cyan', 'bold'),
            ('flag', 'dark gray', 'light gray'),
            ('error', 'dark red', 'light gray'),
        ]

        self.original = files
        self.status = True

        # create columns for the header
        header_cols = urwid.Columns([
            ('weight', 5, urwid.Text(version)),
            ('weight', 7, urwid.Text(u'manual file reorder'))
        ])
        self.header = urwid.Pile([
            urwid.AttrMap(urwid.Padding(header_cols, left=2), 'titlebar'),
            urwid.AttrMap(urwid.Divider(), 'titlebar-divide')
        ])
        self.footer = urwid.Text([
            ('green button', u'ENTER'), u':edit/reorder files  ',
            ('red button', u'ESC'), u':stop editing current directory  ',
            ('green button', u'(r)'), u':reset  ',
            ('red button', u'(q)'), u':save and quit  ',
            ('red button', u'(c)'), u':abort batchren  ',
        ])
        self.view = urwid.Frame(
            header=self.header,
            # body=...,
            footer=self.footer)

    def main(self):
        self.loop = urwid.MainLoop(self.view, self.palette,
            unhandled_input=self.unhandled_input)
        self.loop.run()

        if self.status:
            # regular quit, return rearranged files
            return self.original
        else:
            # abort operation, return None
            return None

    def unhandled_input(self, k):
        if k in ('r', 'R'):
            # reset file order
            raise urwid.ExitMainLoop()

        elif k in ('c', 'C'):
            # abort operation
            self.status = False
            raise urwid.ExitMainLoop()

        elif k in ('q', 'Q'):
            # quit and return rearranged files
            raise urwid.ExitMainLoop()


def main():
    files = [
        'hello',
        'world'
    ]
    d = DirectoryBrowser(files)
    d.main()
